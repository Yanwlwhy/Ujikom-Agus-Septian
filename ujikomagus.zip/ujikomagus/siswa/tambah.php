<?php
include '../config/db.php';


$kelas = mysqli_query($koneksi, "SELECT * FROM kelas");
$spp   = mysqli_query($koneksi, "SELECT * FROM spp");



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $nisn     = $_POST['nisn'] ?? '';
    $nis      = $_POST['nis'] ?? '';
    $nama     = $_POST['nama'] ?? '';
    $id_kelas = $_POST['id_kelas'] ?? '';
    $alamat   = $_POST['alamat'] ?? '';
    $no_telp  = $_POST['no_telp'] ?? '';
    $id_spp   = $_POST['id_spp'] ?? '';

    
    if ($nisn && $nis && $nama && $id_kelas && $alamat && $no_telp && $id_spp) {
        $sql = "INSERT INTO siswa (nisn, nis, nama, id_kelas, alamat, no_telp, id_spp)
                VALUES ('$nisn', '$nis', '$nama', '$id_kelas', '$alamat', '$no_telp', '$id_spp')";


        if (mysqli_query($koneksi, $sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal menyimpan data: " . mysqli_error($koneksi);
        }
    } else {
        $error = "Semua field wajib diisi!";
    }
}
?>


<h2>Tambah Siswa</h2>
<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

<form method="POST">
    <label>NISN</label><br>
    <input type="text" name="nisn" required><br><br>

    <label>NIS</label><br>
    <input type="text" name="nis" required><br><br>

    <label>Nama</label><br>
    <input type="text" name="nama" required><br><br>

    <label>Kelas</label><br>
    <select name="id_kelas" required>
        <option value="">-- Pilih Kelas --</option>
        <?php while ($row = mysqli_fetch_assoc($kelas)) { ?>
            <option value="<?= $row['id_kelas'] ?>"><?= $row['nama_kelas'] ?></option>
        <?php } ?>
    </select><br><br>

    <label>Alamat</label><br>
    <input type="text" name="alamat" required><br><br>

    <label>No Telepon</label><br>
    <input type="text" name="no_telp" required><br><br>

    <label>SPP</label><br>
    <select name="id_spp" required>
        <option value="">-- Pilih SPP --</option>
        <?php while ($row = mysqli_fetch_assoc($spp)) { ?>
            <option value="<?= $row['id_spp'] ?>"><?= $row['tahun'] ?> - <?= $row['nominal'] ?></option>
        <?php } ?>
    </select><br><br>

    <button type="submit">Simpan</button>
</form>
