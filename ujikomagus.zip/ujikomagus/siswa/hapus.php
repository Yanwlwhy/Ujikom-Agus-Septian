<?php
include '../config/db.php';

$nisn = $_GET['nisn'] ?? '';
if (!$nisn) {
    die('NISN tidak ditemukan!');
}

$query = "DELETE FROM siswa WHERE nisn='$nisn'";
mysqli_query($koneksi, $query) or die(mysqli_error($koneksi));

header("Location: index.php");
exit;
