<?php
include '../config/db.php';

$nisn = $_GET['nisn'] ?? '';
if (!$nisn) {
    die('NISN tidak ditemukan!');
}

$siswa = mysqli_query($koneksi, "SELECT * FROM siswa WHERE nisn='$nisn'");
$data = mysqli_fetch_assoc($siswa);

// Data untuk dropdown
$kelas = mysqli_query($koneksi, "SELECT * FROM kelas");
$spp = mysqli_query($koneksi, "SELECT * FROM spp");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nis        = $_POST['nis'] ?? '';
    $nama       = $_POST['nama'] ?? '';
    $id_kelas   = $_POST['id_kelas'] ?? '';
    $alamat     = $_POST['alamat'] ?? '';
    $no_telp    = $_POST['no_telp'] ?? '';
    $id_spp     = $_POST['id_spp'] ?? '';

    $query = "UPDATE siswa SET 
                nis='$nis', 
                nama='$nama', 
                id_kelas='$id_kelas', 
                alamat='$alamat', 
                no_telp='$no_telp', 
                id_spp='$id_spp' 
              WHERE nisn='$nisn'";
    
    mysqli_query($koneksi, $query) or die(mysqli_error($koneksi));
    header("Location: index.php");
    exit;
}
?>

<h2>Edit Data Siswa</h2>
<form method="POST">
    <label>NISN: <?= $nisn ?></label><br>
    <input type="hidden" name="nisn" value="<?= $nisn ?>"><br><br>

    <label>NIS:</label><br>
    <input type="text" name="nis" value="<?= $data['nis'] ?>" required><br><br>

    <label>Nama:</label><br>
    <input type="text" name="nama" value="<?= $data['nama'] ?>" required><br><br>

    <label>Kelas:</label><br>
    <select name="id_kelas" required>
        <option value="">-- Pilih Kelas --</option>
        <?php while ($k = mysqli_fetch_assoc($kelas)) { ?>
            <option value="<?= $k['id_kelas'] ?>" <?= ($k['id_kelas'] == $data['id_kelas']) ? 'selected' : '' ?>>
                <?= $k['nama_kelas'] ?> - <?= $k['kompetensi_keahlian'] ?>
            </option>
        <?php } ?>
    </select><br><br>

    <label>Alamat:</label
