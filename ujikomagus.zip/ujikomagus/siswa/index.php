<?php
include '../config/db.php';
$data = mysqli_query($koneksi, "SELECT * FROM siswa 
    JOIN kelas ON siswa.id_kelas=kelas.id_kelas 
    JOIN spp ON siswa.id_spp=spp.id_spp");
?>
<h2>Data Siswa</h2>
<a href="tambah.php">Tambah Siswa</a>
<table border="1">
<tr>
    <th>NISN</th><th>Nama</th><th>Kelas</th><th>Alamat</th><th>No Telp</th><th>SPP</th><th>Aksi</th>
</tr>
<?php while ($d = mysqli_fetch_assoc($data)) { ?>
<tr>
    <td><?= $d['nisn'] ?></td>
    <td><?= $d['nama'] ?></td>
    <td><?= $d['nama_kelas'] ?></td>
    <td><?= $d['alamat'] ?></td>
    <td><?= $d['no_telp'] ?></td>
    <td><?= $d['nominal'] ?></td>
    <td>
        <a href="edit.php?nisn=<?= $d['nisn'] ?>">Edit</a> | 
        <a href="hapus.php?nisn=<?= $d['nisn'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
    </td>
</tr>
<?php } ?>
</table>
