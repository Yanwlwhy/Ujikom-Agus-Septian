<?php
include '../config/db.php';

$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

$query = "SELECT pembayaran.*, siswa.nama FROM pembayaran 
JOIN siswa ON pembayaran.nisn = siswa.nisn
WHERE MONTH(tgl_bayar) = '$bulan' AND YEAR(tgl_bayar) = '$tahun'";

$result = mysqli_query($koneksi, $query);
?>

<h2>Laporan Pembayaran Bulan <?= $bulan ?>/<?= $tahun ?></h2>
<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Tanggal</th>
        <th>Bulan</th>
        <th>Tahun</th>
        <th>Jumlah</th>
    </tr>
    <?php $no = 1; while ($data = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $data['nama'] ?></td>
            <td><?= $data['tgl_bayar'] ?></td>
            <td><?= $data['bulan_dibayar'] ?></td>
            <td><?= $data['tahun_dibayar'] ?></td>
            <td>Rp<?= number_format($data['jumlah_bayar']) ?></td>
        </tr>
    <?php } ?>
</table>

<script>
    window.print();
</script>
