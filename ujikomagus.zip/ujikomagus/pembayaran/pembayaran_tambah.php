<?php
session_start();
include '../config/db.php';


if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}


$siswa = mysqli_query($koneksi, "SELECT * FROM siswa");
$spp   = mysqli_query($koneksi, "SELECT * FROM spp");


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_petugas = $_SESSION['user']['id_user']; // pastikan 'id_user' sesuai field di database
    $nisn       = $_POST['nisn'];
    $tgl        = $_POST['tgl_bayar'];
    $bulan      = $_POST['bulan_dibayar'];
    $tahun      = $_POST['tahun_dibayar'];
    $id_spp     = $_POST['id_spp'];
    $jumlah     = $_POST['jumlah_bayar'];

  
    if ($nisn && $tgl && $bulan && $tahun && $id_spp && $jumlah) {
        $query = "INSERT INTO pembayaran (id_petugas, nisn, tgl_bayar, bulan_dibayar, tahun_dibayar, id_spp, jumlah_bayar)
                  VALUES ('$id_petugas', '$nisn', '$tgl', '$bulan', '$tahun', '$id_spp', '$jumlah')";
        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal menyimpan pembayaran: " . mysqli_error($koneksi);
        }
    } else {
        $error = "Semua field harus diisi.";
    }
}
?>

<h2>Entri Pembayaran</h2>
<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

<form method="POST">
    <label>NISN:</label><br>
    <select name="nisn" required>
        <option value="">Pilih Siswa</option>
        <?php while ($data = mysqli_fetch_assoc($siswa)) { ?>
            <option value="<?= $data['nisn'] ?>"><?= $data['nisn'] ?> - <?= $data['nama'] ?></option>
        <?php } ?>
    </select><br><br>

    <label>Tanggal Bayar:</label><br>
    <input type="date" name="tgl_bayar" required><br><br>

    <label>Bulan Dibayar:</label><br>
    <input type="text" name="bulan_dibayar" required><br><br>

    <label>Tahun Dibayar:</label><br>
    <input type="text" name="tahun_dibayar" required><br><br>

    <label>SPP:</label><br>
    <select name="id_spp" required>
        <option value="">Pilih SPP</option>
        <?php while ($row = mysqli_fetch_assoc($spp)) { ?>
            <option value="<?= $row['id_spp'] ?>"><?= $row['tahun'] ?> - Rp<?= number_format($row['nominal']) ?></option>
        <?php } ?>
    </select><br><br>

    <label>Jumlah Bayar:</label><br>
    <input type="number" name="jumlah_bayar" required><br><br>

    <button type="submit">Simpan Pembayaran</button>
</form>
