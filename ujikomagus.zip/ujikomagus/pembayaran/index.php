<?php
include '../config/db.php';

$result = mysqli_query($koneksi, "SELECT pembayaran.*, siswa.nama FROM pembayaran 
JOIN siswa ON pembayaran.nisn = siswa.nisn 
ORDER BY tgl_bayar DESC");
?>

<h2>Riwayat Pembayaran</h2>
<li><a href="pembayaran_tambah.php">Tambah Pembayaran</a></li><br><br>
<li><a href="laporan.php">Cetak Laporan Bulanan</a></li><br><br>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>No</th>
        <th>Nama Siswa</th>
        <th>Tanggal Bayar</th>
        <th>Bulan</th>
        <th>Tahun</th>
        <th>Jumlah</th>
    </tr>
    <?php $no = 1; while ($data = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $data['nama'] ?></td>
            <td><?= $data['tgl_bayar'] ?></td>
            <td><?= $data['bulan_dibayar'] ?></td>
            <td><?= $data['tahun_dibayar'] ?></td>
            <td>Rp<?= number_format($data['jumlah_bayar']) ?></td>
        </tr>
    <?php } ?>
</table>
