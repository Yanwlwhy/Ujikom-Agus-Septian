<?php
include '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_kelas'];
    $kompetensi = $_POST['kompetensi_keahlian'];
    mysqli_query($koneksi, "INSERT INTO kelas (nama_kelas, kompetensi_keahlian) VALUES ('$nama', '$kompetensi')");
    header("Location: index.php");
}
?>
<h2>Tambah Kelas</h2>
<form method="POST">
Nama Kelas:<br><input type="text" name="nama_kelas" required><br><br>
Kompetensi:<br><input type="text" name="kompetensi_keahlian" required><br><br>
<button type="submit">Simpan</button>
</form>
