<?php
include '../config/db.php';
$data = mysqli_query($koneksi, "SELECT * FROM kelas");
?>

<h2>Data Kelas</h2>
<a href="tambah.php">+ Tambah Kelas</a><br><br>
<table border="1" cellpadding="10">
<tr><th>No</th><th>Nama Kelas</th><th>Kompetensi</th><th>Aksi</th></tr>
<?php $no=1; while($d = mysqli_fetch_assoc($data)) { ?>
<tr>
<td><?= $no++ ?></td>
<td><?= $d['nama_kelas'] ?></td>
<td><?= $d['kompetensi_keahlian'] ?></td>
<td>
    <a href="edit.php?id=<?= $d['id_kelas'] ?>">Edit</a> |
    <a href="hapus.php?id=<?= $d['id_kelas'] ?>" onclick="return confirm('Hapus data ini?')">Hapus</a>
</td>
</tr>
<?php } ?>
</table>
