<?php
include '../config/db.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM kelas WHERE id_kelas=$id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_kelas'];
    $kompetensi = $_POST['kompetensi_keahlian'];

    mysqli_query($koneksi, "UPDATE kelas SET nama_kelas='$nama', kompetensi_keahlian='$kompetensi' WHERE id_kelas=$id");
    header("Location: index.php");
}
?>

<h2>Edit Kelas</h2>
<form method="POST">
    Nama Kelas: <input type="text" name="nama_kelas" value="<?= $data['nama_kelas'] ?>"><br>
    Kompetensi Keahlian: <input type="text" name="kompetensi_keahlian" value="<?= $data['kompetensi_keahlian'] ?>"><br>
    <button type="submit">Update</button>
</form>
