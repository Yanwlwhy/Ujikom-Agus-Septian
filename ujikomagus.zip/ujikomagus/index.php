<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h2>Hallo!! <?php echo $_SESSION['user']['nama']; ?> Selamat Datang </h2><br>
   <h3> <?php echo $_SESSION['user']['nama']; ?> Mau Kemana Nichhh </h3>
    <ul>
        <li><a href="siswa/">CRUD Data Siswa</a></li>
        <li><a href="user/">CRUD Data Pengguna</a></li>
        <li><a href="kelas/">CRUD Data Kelas</a></li>
        <li><a href="spp/">CRUD Data SPP</a></li>
        <li><a href="pembayaran/">Data Pembayaran</a></li>
      
    </ul>
    <a href="logout.php">Logout</a>
</body>
</html>
