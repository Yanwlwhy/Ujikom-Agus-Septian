<?php
include '../config/db.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM spp WHERE id_spp=$id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tahun = $_POST['tahun'];
    $nominal = $_POST['nominal'];

    mysqli_query($koneksi, "UPDATE spp SET tahun='$tahun', nominal='$nominal' WHERE id_spp=$id");
    header("Location: index.php");
}
?>

<h2>Edit SPP</h2>
<form method="POST">
    Tahun: <input type="text" name="tahun" value="<?= $data['tahun'] ?>"><br>
    Nominal: <input type="number" name="nominal" value="<?= $data['nominal'] ?>"><br>
    <button type="submit">Update</button>
</form>
