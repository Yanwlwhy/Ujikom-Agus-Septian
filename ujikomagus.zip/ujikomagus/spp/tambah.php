<?php
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tahun = $_POST['tahun'];
    $nominal = $_POST['nominal'];

    mysqli_query($koneksi, "INSERT INTO spp (tahun, nominal) VALUES ('$tahun', '$nominal')");
    header("Location: index.php");
}
?>

<h2>Tambah SPP</h2>
<form method="POST">
    Tahun: <input type="text" name="tahun"><br>
    Nominal: <input type="number" name="nominal"><br>
    <button type="submit">Simpan</button>
</form>
