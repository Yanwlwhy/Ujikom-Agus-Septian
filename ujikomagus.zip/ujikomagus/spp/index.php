<?php
include '../config/db.php';
$spp = mysqli_query($koneksi, "SELECT * FROM spp");
?>

<h2>Data SPP</h2>
<a href="tambah.php">Tambah SPP</a>
<table border="1" cellpadding="10">
    <tr>
        <th>No</th>
        <th>Tahun</th>
        <th>Nominal</th>
        <th>Aksi</th>
    </tr>
    <?php $no = 1; while ($row = mysqli_fetch_assoc($spp)): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['tahun'] ?></td>
        <td><?= number_format($row['nominal']) ?></td>
        <td>
            <a href="edit.php?id=<?= $row['id_spp'] ?>">Edit</a> |
            <a href="hapus.php?id=<?= $row['id_spp'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
