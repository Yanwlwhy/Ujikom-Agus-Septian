<?php
include '../config/db.php';
$users = mysqli_query($koneksi, "SELECT * FROM user");
?>

<h2>Data User</h2>
<a href="tambah.php">+ Tambah User</a><br><br>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th><th>Username</th><th>Password</th><th>Aksi</th>
    </tr>
    <?php while($u = mysqli_fetch_assoc($users)) { ?>
    <tr>
        <td><?= $u['id_user'] ?></td>
        <td><?= $u['username'] ?></td>
        <td><?= $u['password'] ?></td>
    
        <td>
            <a href="edit.php?id=<?= $u['id_user'] ?>">Edit</a> |
            <a href="hapus.php?id=<?= $u['id_user'] ?>" onclick="return confirm('Yakin?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>
