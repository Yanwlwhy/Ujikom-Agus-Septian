<?php
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
   

    mysqli_query($koneksi, "INSERT INTO user (username, password) VALUES ('$username', '$password')");
    header("Location: index.php");
}
?>

<h2>Tambah User</h2>
<form method="POST">
    Username:<br><input type="text" name="username" required><br><br>
    Password:<br><input type="password" name="password" required><br><br>
    <button type="submit">Simpan</button>
</form>
