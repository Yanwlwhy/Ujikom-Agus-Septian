<?php
include '../config/db.php';
$id = $_GET['id'];
$user = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM user WHERE id_user='$id'"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];


    mysqli_query($koneksi, "UPDATE user SET username='$username', password='$password' WHERE id_user='$id'");
    header("Location: index.php");
}
?>

<h2>Edit User</h2>
<form method="POST">
    Username:<br><input type="text" name="username" value="<?= $user['username'] ?>" required><br><br>
    Password:<br><input type="text" name="password" value="<?= $user['password'] ?>" required><br><br>
    <button type="submit">Update</button>
</form>
